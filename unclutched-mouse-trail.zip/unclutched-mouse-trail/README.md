# Unclutched Mouse trail

A Pen created on CodePen.io. Original URL: [https://codepen.io/Namitha-S-11465/pen/YzJbrgr](https://codepen.io/Namitha-S-11465/pen/YzJbrgr).

